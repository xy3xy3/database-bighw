url
https://open.bigmodel.cn/api/paas/v4

key
7305f8f725fd64362176a8cc68f1d909.fHTbqG2ArlpGP901

model
glm-4-flash
glm-4-long
embedding-3